import java.util.ArrayList;

public class Empresa extends Persona {

    private ArrayList<Asalariado> asalariados;
    private ArrayList<VendedorComision> vendedoresComision;
    private ArrayList<Cliente> clientes;

    public Empresa() {
        super();
        asalariados = new ArrayList<>();
        vendedoresComision = new ArrayList<>();
        clientes = new ArrayList<>();
    }

    public void contratarAsalariado(String nombre, String cedula, String telefono, String correoElectronico, String direccion, double salario) {
        Asalariado asalariado = new Asalariado(nombre, cedula, telefono, correoElectronico, direccion, salario);
        asalariados.add(asalariado);
    }

    public void contratarVendedorComision(String nombre, String cedula, String telefono, String correoElectronico, String direccion) {
        VendedorComision vendedorComision = new VendedorComision(nombre, cedula, telefono, correoElectronico, direccion);
        vendedoresComision.add(vendedorComision);
    }

    public void registrarVenta(String cedulaVendedor, int cantidadCarrosVendidos) {
        for (VendedorComision vendedorComision : vendedoresComision) {
            if (vendedorComision.getCedula().equals(cedulaVendedor)) {
                vendedorComision.registrarVenta(cantidadCarrosVendidos);
                return;
            }
        }
        System.out.println("Vendedor con cédula " + cedulaVendedor + " no encontrado.");
    }

    public void registrarCliente(String nombre, String cedula, String telefono, String correoElectronico, String direccion) {
        Cliente cliente = new Cliente(nombre, cedula, telefono, correoElectronico, direccion);
        clientes.add(cliente);
    }

    public void registrarCompra(String cedulaCliente, int cantidadCarrosComprados) {
        for (Cliente cliente : clientes) {
            if (cliente.getCedula().equals(cedulaCliente)) {
                cliente.registrarCompra(cantidadCarrosComprados);
                return;
            }
        }
        System.out.println("Cliente con cédula " + cedulaCliente + " no encontrado.");
    }

    public void registrarReserva(String cedulaCliente, String modeloCarro) {
        for (Cliente cliente : clientes) {
            if (cliente.getCedula().equals(cedulaCliente)) {
                cliente.registrarReserva(modeloCarro);
                return;
            }
        }
        System.out.println("Cliente con cédula " + cedulaCliente + " no encontrado.");
    }

    public ArrayList<Asalariado> getAsalariados() {
        return asalariados;
    }

    public ArrayList<VendedorComision> getVendedoresComision() {
        return vendedoresComision;
    }

    public ArrayList<Cliente> getClientes() {
        return clientes;
    }

    public static void main(String[] args) {
        Empresa empresa = new Empresa();

        empresa.contratarAsalariado("Juan Perez", "123456789", "555-5555", "juan.perez@empresa.com", "Calle 1 #1", 2000.0);

        empresa.contratarVendedorComision("Maria Garcia", "987654321", "444-4444", "maria.garcia@empresa.com", "Calle 2 #2");
    }

    public void contratarAsalariado(Asalariado asalariado) {
    }

    public void contratarVendedorComision(VendedorComision vendedorComision) {
    }
}