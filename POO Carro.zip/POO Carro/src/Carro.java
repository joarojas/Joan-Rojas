import java.util.ArrayList;
class Carro {
    public boolean getModelo;

    public Carro(String ford, String mustang, int i, int precioCompra) {
    }

    public void reparar() {
    }

    public String getAnio() {
        return null;
    }

    enum Tipo {RENTA_CAR, INDUSTRIAL, TODOTERRENO};
    enum Reparacion {MECANICA, ELECTRICA, CARROCERIA};

    private String marca;
    private String modelo;
    private String matricula;
    private double precioCompra;
    private double precioVenta;
    private Tipo tipo;
    private ArrayList<Reparacion> reparaciones;
    private Proveedor proveedor;
    private Exposicion exposicion;

    public Carro(String marca, String modelo, String matricula, double precioCompra, double precioVenta, Tipo tipo, Proveedor proveedor) {
        this.marca = marca;
        this.modelo = modelo;
        this.matricula = matricula;
        this.precioCompra = precioCompra;
        this.precioVenta = precioVenta;
        this.tipo = tipo;
        this.proveedor = proveedor;
        this.reparaciones = new ArrayList<>();
    }

    public String getMarca() {
        return marca;
    }

    public String getModelo() {
        return modelo;
    }

    public String getMatricula() {
        return matricula;
    }

    public double getPrecioCompra() {
        return precioCompra;
    }

    public double getPrecioVenta() {
        return precioVenta;
    }

    public Tipo getTipo() {
        return tipo;
    }

    public ArrayList<Reparacion> getReparaciones() {
        return reparaciones;
    }

    public Proveedor getProveedor() {
        return proveedor;
    }

    public Exposicion getExposicion() {
        return exposicion;
    }

    public void setExposicion(Exposicion exposicion) {
        this.exposicion = exposicion;
    }

    public void agregarReparacion(Reparacion reparacion) {
        reparaciones.add(reparacion);
    }

    public boolean necesitaReparacion() {
        return !reparaciones.isEmpty();
    }
}