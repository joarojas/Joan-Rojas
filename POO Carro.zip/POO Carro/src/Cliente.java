public class Cliente {
    private String nombre;
    private String cedula;
    private String telefono;
    private String correoElectronico;
    private String direccion;

    public Cliente(String nombre, String cedula, String telefono, String correoElectronico, String direccion) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.direccion = direccion;
    }

    public String getNombre() {
        return nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setCedula(String cedula) {
        this.cedula = cedula;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public void setCorreoElectronico(String correoElectronico) {
        this.correoElectronico = correoElectronico;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public void registrarCompra(int cantidadCarrosComprados) {
    }

    public void registrarReserva(String modeloCarro) {
    }

    public void comprarCarro(Carro carroVenta) {
    }

    public Carro[] getCarrosComprados() {
        return new Carro[0];
    }
}
