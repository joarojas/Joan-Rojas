class Persona {
    private String nombre;
    private String cedula;
    private String telefono;
    private String correoElectronico;
    private String direccion;

    public Persona(String nombre, String cedula, String telefono, String correoElectronico, String direccion) {
        this.nombre = nombre;
        this.cedula = cedula;
        this.telefono = telefono;
        this.correoElectronico = correoElectronico;
        this.direccion = direccion;
    }

    public Persona() {

    }

    public String getNombre() {
        return nombre;
    }

    public String getCedula() {
        return cedula;
    }

    public String getTelefono() {
        return telefono;
    }

    public String getCorreoElectronico() {
        return correoElectronico;
    }

    public String getDireccion() {
        return direccion;
    }
}