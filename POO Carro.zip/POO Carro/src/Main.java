import java.util.ArrayList;

public class Main {

    // Lista de carros en stock
    private static ArrayList<Carro> stock = new ArrayList<Carro>();

    // Lista de clientes y los carros que han comprado
    private static ArrayList<Cliente> clientes = new ArrayList<Cliente>();

    public static void main(String[] args) {

        // Agregar algunos carros al stock
        agregarCarro(new Carro("Toyota", "Corolla", 2018, 15000));
        agregarCarro(new Carro("Honda", "Civic", 2017, 12000));
        agregarCarro(new Carro("Ford", "Mustang", 2015, 25000));

        // Agregar algunos clientes
        Cliente cliente1 = new Cliente("Juan", "208339487", "809-555-5555", "juan@gmail.com", "Calle 1 #1");
        Cliente cliente2 = new Cliente("María", "208339488", "809-555-5556", "maria@gmail.com", "Calle 2 #2");
        clientes.add(cliente1);
        clientes.add(cliente2);

        // Venta de un carro
        Carro carroVenta = buscarCarro("Toyota", "Corolla");
        if (carroVenta != null) {
            cliente1.comprarCarro(carroVenta);
            stock.remove(carroVenta);
            System.out.println(cliente1.getNombre() + " ha comprado un " + carroVenta.getMarca() + " " + carroVenta.getModelo());
        } else {
            System.out.println("No se encontró el carro deseado en el stock.");
        }

        // Reparación de un carro
        Carro carroReparacion = buscarCarro("Honda", "Civic");
        if (carroReparacion != null) {
            carroReparacion.reparar();
            System.out.println("El " + carroReparacion.getMarca() + " " + carroReparacion.getModelo() + " ha sido reparado.");
        } else {
            System.out.println("No se encontró el carro deseado en el stock.");
        }

        // Compra de un nuevo carro
        Carro carroNuevo = new Carro("Nissan", "Sentra", 2022, 18000);
        agregarCarro(carroNuevo);
        System.out.println("Se ha comprado un " + carroNuevo.getMarca() + " " + carroNuevo.getModelo() + " al proveedor.");

        // Listado de carros en stock
        System.out.println("\nCarros en stock:");
        for (Carro carro : stock) {
            System.out.println(carro.getMarca() + " " + carro.getModelo() + " - Año: " + carro.getAnio() + " - Precio: " + carro.getPrecioCompra());
        }

        // Listado de carros comprados por un cliente
        System.out.println("\nCarros comprados por " + cliente1.getNombre() + ":");
        for (Carro carro : cliente1.getCarrosComprados()) {
            System.out.println(carro.getMarca() + " " + carro.getModelo() + " - Año: " + carro.getAnio() + " - Precio: " + carro.getPrecioVenta());
        }

    }

    // Agregar un carro al stock
    public static void agregarCarro(Carro carro) {
        stock.add(carro);
    }

    // Buscar un carro en el stock por marca y modelo
    public static Carro buscarCarro(String marca, String modelo) {
        for (Carro carro : stock) {
            if (carro.getMarca().equals(marca) && carro.getModelo)
                return carro;
        }
        return null;
    }
}