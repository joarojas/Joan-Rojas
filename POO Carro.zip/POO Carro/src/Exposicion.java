class Exposicion {
    private String nombre;
}
